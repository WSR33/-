﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ООО_Ювелир.Class_folder
{
    class Calculations
    {
        public void AvailablePeriods()
        {

        }
    }
}

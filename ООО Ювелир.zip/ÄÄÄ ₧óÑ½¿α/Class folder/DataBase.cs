﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace ООО_Ювелир.Class_folder
{
    class DataBase
    {
        public static string connectionPath = @"Data Source=PC\SQLEXPRESS01;Initial Catalog=Trade;Integrated Security=True"; //Путь подключения
        public static int roleID;

        public static bool LoginConfirmation(string login, string password) /// Метод проверки пароль и логина
        {
            using (SqlConnection connection = new SqlConnection(connectionPath)) //Использование подключения
            {
                connection.Open();

                string databaseCommand = "SELECT UserLogin, UserPassword, UserRole FROM [User]"; //Создание команды для ридера

                using (SqlCommand command = new SqlCommand(databaseCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {

                    while (reader.Read()) /// Проверка логина и пароль
                    {
                        if (reader["UserLogin"].ToString() == login && reader["UserPassword"].ToString() == password) 
                        {
                            roleID = Convert.ToInt32(reader["UserRole"]);
                            return true;
                        }
                    }
                    connection.Close();
                    return false;
                }
            }
        }

        public static string GetUserFullName(string login, string password)
        {
            using (SqlConnection connection = new SqlConnection(connectionPath)) //Использование подключения
            {
                connection.Open();

                string databaseCommand = "SELECT UserLogin, UserPassword, UserSurname, UserName, UserPatronymic FROM [User]"; //Создание команды для ридера
                string fullName;

                using (SqlCommand command = new SqlCommand(databaseCommand, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {

                    while (reader.Read()) /// Проверка логина и пароль
                    {
                        if (reader["UserLogin"].ToString() == login && reader["UserPassword"].ToString() == password)
                        {
                            fullName = reader["UserSurname"].ToString();
                            fullName += " " + reader["UserName"].ToString();
                            fullName += " " + reader["UserPatronymic"].ToString();

                            return fullName;
                        }
                    }
                    connection.Close();
                    return "";
                }
            }
        }

        public static void DisplayAllProducts(DataGridView dGridView)
        {
            using (SqlConnection connection = new SqlConnection(connectionPath))
            {
                connection.Open();
                DataTable dataTable = new DataTable(); //Создание таблицы для заполнения

                string command = "SELECT ProductArticleNumber AS 'Номер', ProductName AS 'Название товара', ProductDescription AS 'Описание', ProductCost AS 'Цена', ProductQuantityInStock AS 'Наличие на складе' FROM Product2";

                SqlDataAdapter adapter = new SqlDataAdapter(command, connection); //Создание адаптера
                adapter.Fill(dataTable); //Заполнение таблицы адаптером
                dGridView.DataSource = dataTable; //Присвоение ссылки таблицей на заполненную
                connection.Close();
            }
        }
        public static void ChangeConnectionPath(string newSource)
        {
            connectionPath = $"Data Source={newSource};Initial Catalog=Trade;Integrated Security=True";
        }

    }
}

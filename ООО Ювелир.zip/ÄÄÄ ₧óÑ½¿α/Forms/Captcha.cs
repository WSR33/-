﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ООО_Ювелир.Forms
{
    public partial class Captcha : Form
    {
        public Captcha()
        {
            InitializeComponent();
        }

        string text = string.Empty;
        public bool allowToLogIn = false;

        private void Captcha_Load(object sender, EventArgs e)
        {
            picBoxCaptcha.Image = this.CreateImage(picBoxCaptcha.Width, picBoxCaptcha.Height);
        }

        private Bitmap CreateImage(int Width, int Height)
        {
            Random rnd = new Random();

            //Созданин самого изображения
            Bitmap result = new Bitmap(Width, Height);

            // Задача случайной позиции текста
            int Xpos = rnd.Next(0, Width - 100);
            int Ypos = rnd.Next(15, Height - 25);

            //Добавление различных цветов
            Brush[] colors = { Brushes.Black,
                     Brushes.Red,
                     Brushes.Orange,
                     Brushes.Wheat };

            //Где нужно рисовать
            Graphics g = Graphics.FromImage((Image)result);

            //Задание серого задниго фона
            g.Clear(Color.Gray);

            //Для генирование случайного текста
            text = String.Empty;
            string ALF = "1234567890QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
            for (int i = 0; i < 5; ++i)
                text += ALF[rnd.Next(ALF.Length)];

            //Рисовка текста
            g.DrawString(text,
                         new Font("Arial", 24),
                         colors[rnd.Next(colors.Length)],
                         new PointF(Xpos, Ypos));
            //// Добавлние линий

            for (int i = 0; i < Height/19; i++) // Создание горизантальных линий
            {
                g.DrawLine(Pens.Black,
                       new Point(0, i * 20),
                       new Point(Width - 1, i * 20));
            }

            for (int i = 0; i < Width / 19; i++) // Создание вертикальных линий
            {
                g.DrawLine(Pens.Black,
                       new Point(i * 20, 0),
                       new Point(i * 20, Height - 1));
            }


            //Линии от левого до правого угла с верху вниз и наоборот
            g.DrawLine(Pens.Black,
                       new Point(0, 0),
                       new Point(Width - 1, Height - 1));

            g.DrawLine(Pens.Black,
                       new Point(0, Height - 1),
                       new Point(Width - 1, 0));

            //Белые точки
            for (int i = 0; i < Width; ++i)
                for (int j = 0; j < Height; ++j)
                    if (rnd.Next() % 20 == 0)
                        result.SetPixel(i, j, Color.White);

            return result;
        }

        private void BtnCheck_Click(object sender, EventArgs e)
        {
            if (tBoxCaptchaCode.Text == this.text)
            {
                allowToLogIn = true;
                this.Close();
            }
            else
                MessageBox.Show("Неправильно введены символы с картинки");
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            picBoxCaptcha.Image = this.CreateImage(picBoxCaptcha.Width, picBoxCaptcha.Height);
        }
    }
}

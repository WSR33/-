﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ООО_Ювелир
{
    public partial class LoginFrame : Form
    {
        public LoginFrame()
        {
            InitializeComponent();
        }

        private void BtnLogIn_Click(object sender, EventArgs e)
        {
            string login = tBoxLogin.Text;
            string pass = tBoxPassword.Text;

            if(!Class_folder.DataBase.LoginConfirmation(login, pass) )
            {
                MessageBox.Show("Неправильно введен логин или пароль", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Forms.Captcha captchaForm = new Forms.Captcha();
            captchaForm.ShowDialog();

            if (!captchaForm.allowToLogIn)
                return;

            this.Hide();
            Forms.AdminFrame adminForm = new Forms.AdminFrame();
            adminForm.ChangeUserName(Class_folder.DataBase.GetUserFullName(login, pass));
            adminForm.ShowDialog();

            if (adminForm.backToLogin)
                this.Show();
            else
                this.Close();
        }
    }
}

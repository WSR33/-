﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ООО_Ювелир.Forms
{
    public partial class AdminFrame : Form
    {
        public AdminFrame()
        {
            InitializeComponent();

            Class_folder.DataBase.DisplayAllProducts(dGridProducts);
        }

        public bool backToLogin = false;

        public void ChangeUserName(string fullName) // смена имени пользователя
        {
            labelUserName.Text = $"Вход выполнен под: {fullName}";
        }

        private void BtnLogOut_Click(object sender, EventArgs e) // кнопка выхода
        {
            backToLogin = true;
            this.Close();
        }

        private void BtnAddProduct_Click(object sender, EventArgs e) // кнопка добавление товара
        {
            Forms.AddProduct formAdd = new Forms.AddProduct();
            formAdd.ShowDialog();
        }

        private void BtnEditProduct_Click(object sender, EventArgs e) // Кнопка изменение товара
        {
            Forms.EditProduct formEdit = new Forms.EditProduct();
            formEdit.ShowDialog();
        }
    }
}
